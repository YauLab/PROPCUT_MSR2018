File details:

propcut_int_x: Subject response data for the subject x = 1, 2 ... 8. Each file contains 5 variables. Each varilabe is in Matlab cell format that corresponds to one stimulus condition.

generateFigExp2.m: Matlab code that generates plots with psychometric curves and PSE and JND.

getStatsExp2.R: R code for statistical analysis. Files names started with rmANOVA are required for these analyses.
